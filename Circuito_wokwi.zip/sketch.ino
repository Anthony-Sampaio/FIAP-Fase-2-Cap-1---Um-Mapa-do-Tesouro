// muda os valores aqui pra testar
float umidade = 50.0;
float ph      = 6.0;
bool  n       = true;
bool  p       = true;
bool  k       = true;
int   cultura = 1; // 1 cana, 2 laranja

#define PINO_RELE 5
#define PINO_LED  2

void setup() {
  Serial.begin(9600);
  pinMode(PINO_RELE, OUTPUT);
  pinMode(PINO_LED, OUTPUT);
  digitalWrite(PINO_RELE, LOW);
  digitalWrite(PINO_LED, LOW);

  Serial.println();
  Serial.println("FarmTech Solutions - Irrigacao");
  Serial.println();
}

void loop() {
  float umidMin, phMin, phMax;
  String nomeCultura;
  if (cultura == 1) {
    nomeCultura = "Cana";
    umidMin = 60.0; phMin = 5.5; phMax = 7.0;
  } else {
    nomeCultura = "Laranja";
    umidMin = 40.0; phMin = 5.0; phMax = 6.5;
  }

  bool umidOk = (umidade >= umidMin);
  bool phOk   = (ph >= phMin && ph <= phMax);

  bool ligaBomba = false;
  String motivos = "";

  if (!umidOk) { ligaBomba = true; motivos += "umidade baixa, "; }
  if (!phOk)   { ligaBomba = true; motivos += "ph fora, "; }
  if (!n)      { ligaBomba = true; motivos += "sem N, "; }
  if (!p)      { ligaBomba = true; motivos += "sem P, "; }
  if (!k)      { ligaBomba = true; motivos += "sem K, "; }

  digitalWrite(PINO_RELE, ligaBomba ? HIGH : LOW);
  digitalWrite(PINO_LED,  ligaBomba ? HIGH : LOW);

  Serial.print("Cultura: "); Serial.println(nomeCultura);

  Serial.print("Umidade: "); Serial.print(umidade, 1); Serial.print("%");
  Serial.print(umidOk ? " ok" : " baixa");
  Serial.print(" (min "); Serial.print(umidMin, 0); Serial.println("%)");

  Serial.print("pH: "); Serial.print(ph, 1);
  Serial.print(phOk ? " ok" : " fora");
  Serial.print(" ("); Serial.print(phMin, 1);
  Serial.print("-"); Serial.print(phMax, 1); Serial.println(")");

  Serial.print("N:"); Serial.print(n ? "ok" : "nao");
  Serial.print("  P:"); Serial.print(p ? "ok" : "nao");
  Serial.print("  K:"); Serial.println(k ? "ok" : "nao");

  if (ligaBomba) {
    Serial.print("Bomba LIGADA - ");
    Serial.println(motivos);
  } else {
    Serial.println("Bomba desligada");
  }

  Serial.println();
  delay(2000);
}
